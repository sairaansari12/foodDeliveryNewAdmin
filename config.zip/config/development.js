const db = require('./db');
module.exports = {
	db: db.development,
	PORT:9062,
	mediapath: 'public/company/',
	dirnames : ['images', 'thumbnails', 'audios', 'videos','documents'],
	jwtToken: 'PGSGFUISBHS=^$#*(%^#',
	saltRounds: 10,
	authTokenExpiration: '7d',
	refreshTokenExpiration: '30d',
	MAIL_USERNAME:'',
	MAIL_PASSWORD:'',
	FCM_KEY:'AAAAlFPLn38:APA91bGhgdz4LngwoCUCkX8MxZTLWdy3YukGvNVHc8LXb6f5q4RD-UKd4Hw4WWT8qXBRgt9yEVGV3JMjGkjgYfuHyN_WdBezaP-1Bw0CK9k8KqMtJ6CeeKoNfU4dGV7L4tgS4pVCvpoi',
	UPLOAD_DIRECTORY:'public/',
	// IMAGE_APPEND_URL:'http://51.79.40.224:9061/',
	//IMAGE_APPEND_URL:'http://51.79.40.224:9075/',
	IMAGE_APPEND_URL:'http://localhost:9062/',

	NOTIFICATION_KEY:'AAAAlFPLn38:APA91bGhgdz4LngwoCUCkX8MxZTLWdy3YukGvNVHc8LXb6f5q4RD-UKd4Hw4WWT8qXBRgt9yEVGV3JMjGkjgYfuHyN_WdBezaP-1Bw0CK9k8KqMtJ6CeeKoNfU4dGV7L4tgS4pVCvpoi',
	NOTIFICATION_EMP_KEY:'bvcbcv',
	REMINDER_MAIL:'info@homeservices',
	EMAIL_HOST :'',
	EMAIL_KEY :'apikey',
	INVOICE_SUBJECT:'Info Message',
	FOROGT_SUBJECT:'Reset Password request',
	EMAIL_PASS :''  , 
	APP_NAME:'Home Services',
	MSALT:"hxKUWcp1kl",
	MKEY:"83TmAbfL",
	MHEADER:"MGpoX7As6xT5/SpZ9kz/bvSvTUbSM6GcN5qnOxGmKDM="

};
